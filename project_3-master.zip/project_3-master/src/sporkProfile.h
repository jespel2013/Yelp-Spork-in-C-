//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef SPORKPROFILE_H
#define SPORKPROFILE_H

#include <string>

#define MAX_SPORK_PROFILES 500

/**
 * @datamember businessName is the name of the Business
 * @datamember locX is the "x" location on a grid
 * @datamember locY is the "y" location on a grid
 * @datamember distMiles is the distance of the Business to the user
 * @datamember avgRating is the average rating of the Business
 * @datamember adLevel is the ad level of the Business
 */
class SporkProfile{
private:
    std::string _businessName;
    double _locX;
    double _locY;
    double _distMiles;
    double _avgRating;
    int _adLevel;
public:
    bool IsValid();
    SporkProfile();
    SporkProfile(std::string busName, double busXLoc, double busYLoc, double rating, int adLevel, double userXLoc, double userYLoc);
    
    std::string GetBusinessName() { return _businessName; };
    double GetLocX() { return _locX; };
    double GetLocY() { return _locY; };
    double GetDistMiles() { return _distMiles; };
    double GetAvgRating() { return _avgRating; };
    int GetAdLevel() { return _adLevel; };
    void SetBusinessName(std::string businessName) { _businessName = businessName; };
    void SetLocX(double locX) { _locX = locX; };
    void SetLocY(double locY) { _locY = locY; };
    void SetDistMiles(double distMiles) { _distMiles = distMiles; };
    void SetAvgRating(double avgRating) { _avgRating = avgRating; };
    void SetAdLevel(int adLevel) { _adLevel = adLevel; };
};

#endif
