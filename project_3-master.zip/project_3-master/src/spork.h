//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef SPORK_H
#define SPORK_H

#include <string>
#include "sporkProfile.h"

#define MAX_SPORK_PROFILES 500

class Spork{
private:
    unsigned int _num_profiles;
    int _best_business_index;
    double _minRating;
    double _maxDistFromUser;
    double _userXLoc;
    double _userYLoc;
    SporkProfile _profiles[MAX_SPORK_PROFILES];
public:
    Spork(double minRating, double maxDistFromUser, double userXLoc, double userYLoc);
    
    unsigned int GetNumProfiles() { return _num_profiles; };
    SporkProfile* GetProfiles() { return _profiles; };
    void SetNumProfiles(unsigned int num_profiles) { _num_profiles = num_profiles; };
    int GetBestBusinessIndex() { return _best_business_index; };
    void ReadSporkDataFromFile(std::string fileName);
    void AddProfile(SporkProfile newProfile);
    void FindBestBusinessIndex();
    void WriteSporkResultsToFile(std::string fileName);
};

#endif
