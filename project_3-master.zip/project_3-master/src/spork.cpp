//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "sporkProfile.h"
#include "spork.h"
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>

using namespace std;

// constructor written for you.
Spork::Spork(double minRating, double maxDistFromUser, double userXLoc, double userYLoc){
    _maxDistFromUser = maxDistFromUser;
    _minRating = minRating;
    _num_profiles = 0;
    _best_business_index = -1;
    _userXLoc = userXLoc;
    _userYLoc = userYLoc;
}

/**
* Adds a profile to to global profiles and increments the total number of profiles kept
*
* @param Sporkprofile to add
*
* @requirement must not exceed the maximum number of profiles
*/
void Spork::AddProfile(SporkProfile newProfile) {
	
	if (_num_profiles == MAX_SPORK_PROFILES) {
		/*cout << "Max profiles reached" << endl;*/
		return;
	}
	else {
		_profiles[_num_profiles] = newProfile;
		_num_profiles += 1;
	}


	return;
}


/**
 * Reads data from a specified file and creates SporkProfiles for each Business to be placed in the _profiles variable.
 * @param filename is a std::string with a path to a file
 *
 * @requirement Each Business is formatted as such in the file:
 *
 *    BusinessName X.XX Y.YY R.RR A
 *
 * BusinessName is the name of the restaurant/business. The business name will not include any
 * whitespace characters
 * X.XX represents the X location in miles using a Cartesian coodinate system
 * Y.YY represents the Y location in miles using a Cartesian coodinate system
 * R.RR represents the average rating for the business
 * A is the advertising level
 *
 * @requirement profile should be added to _profiles only if it is valid
 */
void Spork::ReadSporkDataFromFile(std::string fileName){
	SporkProfile();
	//create input stream
	//parse out information
	//create spork profile

	//information
	std::string busName;
	double xLoc, yLoc;
	double rating;
	int level;

	std::string extra;
	std::string compareLine;



	std::ifstream inputStream; 
	inputStream.open(fileName);

	if (!inputStream.is_open()) {
		cout << "File did not open" << endl;
		return;
	}

	while (!inputStream.eof()) {
		inputStream >> busName >> xLoc >> yLoc >> rating >> level >> extra;

		SporkProfile tempProfile(busName, xLoc, yLoc, rating, level, _userXLoc, _userYLoc);
		

		if (tempProfile.IsValid()) {
			AddProfile(tempProfile);
		}
		else {
			cout << "Profile is not valid" << endl;
		}
	}
	inputStream.close();

	return;
}


/**
 * Returns the index of the "best" profile.
 *
 * @requirement profile avgRating must be >= _minRating
 * @requirement profile distMiles must be <= _maxDistFromUser
 * @requirement Business must have the highest adLevel out of all Businesses that are
 * both nearby and good
 * @requirement In the event of a tie, the first Business that is found is the "best"
 */
void Spork::FindBestBusinessIndex(){

	unsigned int i = 0;
	int tempAd = -1;
	int bestIndex = -1;

	for (i = 0; i < _num_profiles; i++) {
		if (_profiles[i].GetAvgRating() >= _minRating && _profiles[i].GetDistMiles() <= _maxDistFromUser) {
			if (_profiles[i].GetAdLevel() > tempAd) {
				tempAd = _profiles[i].GetAdLevel();
				bestIndex = int(i);
			}	
		}
	}
	_best_business_index = bestIndex;

	return;

}

/* Prints all profiles to a file putting each profile on its own line in the file
 *
 * @requirement Business at maxSponsorIndex must be printed first, unless there is no
 * "best" Business
 *
 * @requirement each business must be printed in the format:
 *
 * BusinessName R.RR D.DD
 *
 * where R.RR is the average rating with exactly two decimal digits of precision,
 * and D.DD is the distance in miles with exactly two decimal digits of precision,
 * and BusinessName, rating, and distance are all separated by a TAB (\t) character
 *
 * @requirement All SporkProfiles are printed in the order they were encountered.
 *
 */
void Spork::WriteSporkResultsToFile(std::string fileName){


	unsigned int i;
	std::ofstream outStream;
	outStream.open(fileName);

	if (!outStream.is_open()) {
		cout << "File did not open" << endl;
		return;
	}
	if (_best_business_index != -1) {
		outStream << _profiles[_best_business_index].GetBusinessName() << "\t" << setprecision(2) << fixed << _profiles[_best_business_index].GetAvgRating() << "\t" << setprecision(2) << fixed << _profiles[_best_business_index].GetDistMiles() << endl;
	}
	for (i = 0; i < _num_profiles; i++) {
		if (int(i) == _best_business_index) {
		}
		else {
			outStream << _profiles[i].GetBusinessName() << "\t" << setprecision(2) << fixed << _profiles[i].GetAvgRating() << "\t" <<setprecision(2) << fixed  << _profiles[i].GetDistMiles() << endl;
		}
	}
	outStream.close();
	return;
}
