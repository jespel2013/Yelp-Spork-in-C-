//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "sporkProfileTest.h"
#include "sporkProfileEndToEndTest.h"


int main() {
    
    SporkProfileTester sporkTest;
    sporkTest.TestSporkProfile();
    
    SporkEndToEndTester endToEndTest;
    endToEndTest.RunAllTests();
    
    return 0;
}
