//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//


#include "sporkProfile.h"
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cmath>

using namespace std;

// default constructor written for you.
SporkProfile::SporkProfile(){
    _adLevel = 0;
    _avgRating = 0.0;
    _locX = 0.0;
    _locY = 0.0;
    _distMiles = 0.0;
}

/**
 * Calculates a distance between a business and the user using the standard distance formula and assigns it to the profiles distance
 *
 * @param profile is a pointer to SporkProfile of business
 * @param userLocX is the user's "x" location on a grid
 * @param userLocY is the user's "y" location on a grid
 */
SporkProfile::SporkProfile(std::string busName, double busXLoc, double busYLoc, double avgRating, int adLevel, double userXLoc, double userYLoc){

}

/**
 * Verifies whether a SporkProfile is valid.
 *
 * @requirement AdLevel must be >= 0 and <= 2
 * @requirement Average rating must be >= 0 and <= 5
 * @requirement businessName must have length greater than 0
 *
 * @return true if profile is valid, false otherwise
 */
bool SporkProfile::IsValid(){
    return false;
}
