//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "sporkProfileEndToEndTest.h"
#include "sporkProfile.h"
#include "spork.h"
#include <sstream>
#include <fstream>
#include <iostream>

using namespace std;

void SporkEndToEndTester::RunAllTests(){
    for (int i = 0; i < 10; i++){
        cout << "testFile" << i << " " <<
        (TestFile(i) ? "passed." : "failed.") << endl;
    }
}

/*
 * @requirement pass if all lines in the output file output[testNum].txt are the same as the output file produced from your program.
 * @return pass: 1, fail: 0
 */
bool SporkEndToEndTester::TestFile(unsigned int testNum){
    double minRating;
    double maxDistFromUser;
    double userXLoc;
    double userYLoc;
    
    // this creates a file path that will change depending on the operating system and
    // the testNumber
    // TODO: You need to create paths to the input files, test descriptions, output files
    // appropriately.

	stringstream inFileName;
	stringstream outFileName;
	stringstream fileName;

	ifstream inFS;
	ifstream outFS;
	ifstream FS;

	string test1;
	string test2;

    stringstream testDescriptionPath;
    testDescriptionPath << TEST_FILE_RELATIVE_PATH << "/testDescription" << testNum + 1 << ".txt";

	inFileName << TEST_FILE_RELATIVE_PATH << "/input" << testNum + 1 << ".txt";
	fileName << TEST_FILE_RELATIVE_PATH << "/output" << testNum + 1 << ".txt";
	outFileName << TEST_FILE_RELATIVE_PATH << "/myoutput" << testNum + 1 << ".txt";
    
    ifstream testDescStream;
    testDescStream.open(testDescriptionPath.str());
    testDescStream >> userXLoc >> userYLoc >> maxDistFromUser >> minRating;
    
    Spork spork(minRating, maxDistFromUser, userXLoc, userYLoc);
    
    // The spork object is now created, you just need to call the main functions here
    // Read from file
	spork.ReadSporkDataFromFile(inFileName.str());
    // Find the best business
	spork.FindBestBusinessIndex();
    // Print out the results
	spork.WriteSporkResultsToFile(outFileName.str());
	spork.WriteSporkResultsToFile(fileName.str());
    
    // now you need to open the output file you created and compare
    // it line-by-line with the output file provided to you.

	outFS.open(outFileName.str());
	FS.open(fileName.str());

	while (!outFS.eof()) {
		getline(outFS, test1);
		getline(FS, test2);

		if (test1.compare(test2) != 0) {
			return false;
		}
	}

	if (!outFS.is_open()) {
		cout << "File failed to open" << endl;
		return false;
	}
    
    
    // return true if the files are identical line-by-line
	cout << "Files are identical" << endl;
	return true;
}
