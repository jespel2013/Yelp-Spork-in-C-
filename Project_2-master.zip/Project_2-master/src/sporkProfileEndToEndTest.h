//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef SPORKPROFILEENDTOEND_H
#define SPORKPROFILEENDTOEND_H

#include <stdio.h>
#include <string.h>
#include "sporkProfile.h"

#ifdef __linux__
    // definitely do not modify this, this will cause trouble
    #define TEST_FILE_RELATIVE_PATH "../../test_files"
#elif __APPLE__
    #define TEST_FILE_RELATIVE_PATH "../../../test_files"
#else
    #define TEST_FILE_RELATIVE_PATH "../test_files"
#endif


class SporkEndToEndTester{
public:
    void RunAllTests();
    bool TestFile(unsigned int testNum);
};

#endif /* sporkProfileEndToEnd_h */
