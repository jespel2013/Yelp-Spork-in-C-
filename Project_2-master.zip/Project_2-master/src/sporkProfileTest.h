//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef SPORKPROFILETEST_H
#define SPORKPROFILETEST_H

class SporkProfileTester{
public:
    void TestSporkProfile();
    bool TestCreateSporkProfile();
    bool TestIsValidProfileAvgRatingNegative();
    bool TestIsValidProfileAdLevelThree();
    bool TestIsValidProfileBlankBusinessName();
    bool TestAddProfileWithMaxSporkProfiles();
    bool TestAddProfileExceedsMaxSporkProfiles();
    bool TestGetBestBusinessAdLevelZero();
    bool TestGetBestBusinessAdLevelOne();
    
    bool TestGetBestBusinessAdLevelTwo();
    bool TestGetBestBusinessListsFirstBusinessAdLevelTwo();
    bool TestGetBestBusinessNoBestBusiness();
};

#endif
