//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "sporkProfileTest.h"
#include "spork.h"
#include "sporkProfile.h"
#include <cmath>

// you can leave this alone.
void SporkProfileTester::TestSporkProfile(){
    TestCreateSporkProfile();
    TestIsValidProfileAvgRatingNegative();
    TestIsValidProfileAdLevelThree();
    TestIsValidProfileBlankBusinessName();
    TestAddProfileWithMaxSporkProfiles();
    TestAddProfileExceedsMaxSporkProfiles();
    TestGetBestBusinessAdLevelZero();
    TestGetBestBusinessAdLevelOne();
    TestGetBestBusinessAdLevelTwo();
    TestGetBestBusinessListsFirstBusinessAdLevelTwo();
    TestGetBestBusinessNoBestBusiness();
}

/*
 * @requirement pass if all members of profile are correctly assigned and distance is correctly caclulated:
 * @hint you will need to make the distance is calculated within a margin of error of about .001. You may use the <cmath> library.
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestCreateSporkProfile(){

	SporkProfile testProfile;

	testProfile = SporkProfile("DaBiznuss", 3.0, 4.0, 3.50, 1, 0.0, 0.0);
	double actualDistance = 5.0;

	double distance = testProfile.GetDistMiles();


	if (((testProfile.GetBusinessName().compare("DaBiznuss")) == 0) && (testProfile.GetLocX() == 3.0) && (testProfile.GetLocY() == 4.0) && (testProfile.GetAvgRating() == 3.50) &&
		(testProfile.GetAdLevel() == 1) && (fabs(distance - actualDistance) <= 0.001)) {

		return true;
	}

    return false;
}

/*
 * @requirement pass if profile IsValid() returns false when avgRating is negative and all other properties are valid
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestIsValidProfileAvgRatingNegative(){

	SporkProfile testProfile;

	testProfile = SporkProfile("DaBiznuss", 3.0, 4.0, -3.50, 1, 0.0, 0.0);

	if (!testProfile.IsValid()) {
		return true;
	}

    return false;
}

/*
 * @requirement pass if profile IsValid() returns false when adLevel is 3 and all other properties are valid
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestIsValidProfileAdLevelThree(){

	SporkProfile testProfile;

	testProfile = SporkProfile("DaBiznuss", 3.0, 4.0, 3.50, 3, 0.0, 0.0);

	if (!testProfile.IsValid()) {
		return true;
	}
    return false;
}

/*
 * @requirement pass if profile IsValid() returns false when BusinessName is blank and all other properties are valid
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestIsValidProfileBlankBusinessName(){
	SporkProfile testProfile;

	testProfile = SporkProfile("", 3.0, 4.0, 3.50, 1, 0.0, 0.0);

	if (!testProfile.IsValid()) {
		return true;
	}

    return false;
}

/*
 * @requirement pass if numProfiles is MAX_SPORK_PROFILES when exactly MAX_SPORK_PROFILES profiles are given to AddProfile
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestAddProfileWithMaxSporkProfiles(){

	SporkProfile testProfile;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile = SporkProfile("testBizness", 3.0, 4.0, 3.50, 1, 0.0, 0.0);

	int i = 0;

	for (i = 0; i < MAX_SPORK_PROFILES; ++i) {
		testSpork.AddProfile(testProfile);
	}

	if ((testSpork.GetNumProfiles() == MAX_SPORK_PROFILES)) {
		return true;
	}
    
    return false;
}

/*
 * @requirement pass if addProfile does not increase the number of profiles beyond MAX_SPORK_PROFILES when MAX_SPORK_PROFILES + 1 profiles are passed to addProfile
 * @return pass: true, fail: false
 */
bool SporkProfileTester::TestAddProfileExceedsMaxSporkProfiles(){
	SporkProfile testProfile;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile = SporkProfile("testBizness", 3.0, 4.0, 3.50, 1, 0.0, 0.0);

	int i = 0;

	for (i = 0; i < MAX_SPORK_PROFILES + 1; ++i) {
		testSpork.AddProfile(testProfile);
	}

	if ((testSpork.GetNumProfiles() == MAX_SPORK_PROFILES)) {
		return true;
	}

	return false;
}

/*
 * @requirement pass if GetBestBusinessIndex returns correct index when 2 or more profiles exist in _profiles and both ad levels are zero. You will need to call FindBestBusinessIndex to calculate GetBestBusinessIndex
 * @return  pass: true, fail: false
 */
bool SporkProfileTester::TestGetBestBusinessAdLevelZero(){
	SporkProfile testProfile;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile = SporkProfile("testBizness", 3.0, 4.0, 3.50, 0, 0.0, 0.0);

	int i = 0;

	for (i = 0; i < 3; ++i) {
		testSpork.AddProfile(testProfile);
	}

	testSpork.FindBestBusinessIndex();

	if (testSpork.GetBestBusinessIndex() == 0) {
		return true;
	}

	return false;
}
    
/*
 * @requirement pass if GetBestBusinessIndex returns correct index when 2 or more profiles exist in _profiles and one ad level is zero and another is 1. You will need to call FindBestBusinessIndex to calculate GetBestBusinessIndex
 * @return  pass: true, fail: false
 */
bool SporkProfileTester::TestGetBestBusinessAdLevelOne() {
	SporkProfile testProfile1, testProfile2;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile1 = SporkProfile("testBizness", 3.0, 4.0, 3.50, 1, 0.0, 0.0);
	testProfile2 = SporkProfile("testBizness2", 3.0, 4.0, 3.50, 0, 0.0, 0.0);


	testSpork.AddProfile(testProfile1);
	testSpork.AddProfile(testProfile2);


	testSpork.FindBestBusinessIndex();

	if (testSpork.GetBestBusinessIndex() == 0) {
		return true;
	}

	return false;
}

/*
 * @requirement pass if GetBestBusinessIndex returns correct index when 2 or more profiles exist in _profiles and one ad level is zero and another is 2. You will need to call FindBestBusinessIndex to calculate GetBestBusinessIndex
 * @return  pass: true, fail: false
 */
bool SporkProfileTester::TestGetBestBusinessAdLevelTwo(){
	SporkProfile testProfile1, testProfile2;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile1 = SporkProfile("testBizness", 3.0, 4.0, 3.50, 2, 0.0, 0.0);
	testProfile2 = SporkProfile("testBizness2", 3.0, 4.0, 3.50, 0, 0.0, 0.0);


	testSpork.AddProfile(testProfile1);
	testSpork.AddProfile(testProfile2);


	testSpork.FindBestBusinessIndex();

	if (testSpork.GetBestBusinessIndex() == 0) {
		return true;
	}
    return false;
}

/*
 * @requirement pass if GetBestBusinessIndexs returns correct index when 2 or more profiles exist in _profiles and both ad levels are 2. You will need to call FindBestBusinessIndex to calculate GetBestBusinessIndex
 * @return  pass: true, fail: false
 */
bool SporkProfileTester::TestGetBestBusinessListsFirstBusinessAdLevelTwo(){
	SporkProfile testProfile1, testProfile2;
	Spork testSpork = Spork(0.0, 40.0, 7.00, 8.00);

	testProfile1 = SporkProfile("testBizness", 3.0, 4.0, 3.50, 2, 0.0, 0.0);
	testProfile2 = SporkProfile("testBizness2", 3.0, 4.0, 3.50, 2, 0.0, 0.0);


	testSpork.AddProfile(testProfile1);
	testSpork.AddProfile(testProfile2);

	testSpork.FindBestBusinessIndex();

	if (testSpork.GetBestBusinessIndex() == 0) {
		return true;
	}
    return false;
}

/*
 * @requirement pass if GetBestBusinessIndex returns -1 when no business has avgRating >= minRating and distMiles <= maxDistFromUser
 * @return  pass: true, fail: false
 */
bool SporkProfileTester::TestGetBestBusinessNoBestBusiness(){
	SporkProfile testProfile1, testProfile2;
	Spork testSpork = Spork(1.5, 2.00, 7.00, 8.00);

	testProfile1 = SporkProfile("testBizness", 3.0, 4.0, 1.0, 1, 0.0, 0.0);
	testProfile2 = SporkProfile("testBizness2", 3.0, 4.0, 1.2, 0, 0.0, 0.0);

	testSpork.AddProfile(testProfile1);
	testSpork.AddProfile(testProfile2);

	testSpork.FindBestBusinessIndex();

	if (testSpork.GetBestBusinessIndex() == -1) {
		return true;
	}
    return false;
}
